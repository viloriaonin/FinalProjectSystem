CREATE DATABASE IF NOT EXISTS `barangay`;

USE `barangay`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `activity_log`;

CREATE TABLE `activity_log` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

INSERT INTO `activity_log` VALUES (1,"1077284998617fe00a684fac75f578567ad56a78721032503143c00","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Monday November 1, 08:39 PM"),
(2,"1114966200617e4f71b525feecec7a51354075281a704668d9da356","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Sunday October 31, 04:10 PM"),
(3,"115957969161840c0172100bf29b74c8aabac937eeeb4a63a04bec5",1,"You Logout at Computer Windows 10","2021 Friday November 5, 12:36 AM"),
(4,"136685700761840ba5e266e3d1ffe905d7848f6d85069817b2e4839",000001,"You Logout at Computer Windows 10","2021 Friday November 5, 12:34 AM"),
(5,"1391493196616ff6f5dc669e37539edfd04ed293a41d984e9ef4628","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Wednesday October 20, 07:01 PM"),
(6,"1731023584616ed723a76dc7538a01b6713a6ecd4d479dccc65b7fd","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Tuesday October 19, 10:33 PM"),
(7,"174628555616fe489e0702990c6bc9658f84f0628ce57b4ca42c97","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Wednesday October 20, 05:42 PM"),
(8,"1840559802616ed831ae663469fa8cd4a2b99d4b14793e87ef9737a","55450267616e89983f9824409bc301b0ca29757ca2f408d2833f5","You Logout at Computer Windows 10","2021 Tuesday October 19, 10:37 PM"),
(9,"185968792616ed79e246243b8e5b1b8f3880c0ad2e5770917beed4","55450267616e89983f9824409bc301b0ca29757ca2f408d2833f5","You Login at Computer Windows 10","2021 Tuesday October 19, 10:35 PM"),
(10,"187113579617fda05bd46a53c617e551ee22eb2b8bea9d105c2a49","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Monday November 1, 08:13 PM"),
(11,"193331601361840acc1f15c9210b5bf5c5cefbba7930b11a5e9d139",1,"You Logout at Computer Windows 10","2021 Friday November 5, 12:31 AM"),
(12,"1961859129616fe1793f0719115c76418b27ff537f02c80d1b253b2","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Wednesday October 20, 05:29 PM"),
(13,"1967771003616ff8a9e589a7d684e5fea3698db8c11e4559a5ac1fe","1619131353616ff7b8abf9369d87134dd66fc48df5b2e9b3f297d63","You Logout at Computer Windows 10","2021 Wednesday October 20, 07:08 PM"),
(14,"263079144617fe15bb83987b1a3830d5bc7b959df1ba08bacae0f7",1,"You Logout at Computer Windows 10","2021 Monday November 1, 08:45 PM"),
(15,"323917335616fe23510f9a8725bd8e64ef9e97f93b1b3879150d42","55450267616e89983f9824409bc301b0ca29757ca2f408d2833f5","You Logout at Computer Windows 10","2021 Wednesday October 20, 05:32 PM"),
(16,"428611640616ff997244c292240b9e6ecea9a6a906a0d76aab2d2c","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Wednesday October 20, 07:12 PM"),
(17,"487165185617e946779b691eb77bb715ee5acba81fa314b964ffd5","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Sunday October 31, 09:04 PM"),
(18,"588709533616ff2dfd74d6b0672bf50c740b44278a5e43519f21bc","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Wednesday October 20, 06:43 PM"),
(19,"614047923616ff8de9838d01b88184e3f18056ae388d850d1d2ee4","1619131353616ff7b8abf9369d87134dd66fc48df5b2e9b3f297d63","You Logout at Computer Windows 10","2021 Wednesday October 20, 07:09 PM"),
(20,"656714458616fe357b0a833ea7bf47d057ad313be5dab2abbfa4e7","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Wednesday October 20, 05:37 PM"),
(21,"675802690617fe817e1fb72413f299ec7671f7c551cb8c90757bf3",1,"You Logout at Computer Windows 10","2021 Monday November 1, 09:13 PM"),
(22,"6806075556170409ce68957d13ad3bf225fcad132ac367c39b98f9","334232133616e8766ccea86806518a773ad7072abb56bccaddd089","You Logout at Computer Windows 10","2021 Thursday October 21, 12:15 AM"),
(23,"7299655436182766cc7f0cfb119449b6d772ccca1d70552bbe679a",1,"You Logout at Computer Windows 10","2021 Wednesday November 3, 07:45 PM"),
(24,"745953584618285a7076291fb75d20813a7860e373929085c5c832",000002,"You Logout at Computer Windows 10","2021 Wednesday November 3, 08:50 PM"),
(25,"80943938561854d350b202b3ef2f7dc0a7c80dfed9fa07fbdee15f",1,"You Logout at Computer Windows 10","2021 Friday November 5, 11:26 PM"),
(26,"97777390661840c76292019d80238dc37eedd35be3b5581a2b8725",1,"You Logout at Computer Windows 10","2021 Friday November 5, 12:38 AM");


DROP TABLE IF EXISTS `barangay_information`;

CREATE TABLE `barangay_information` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `zone` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `address` varchar(69) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `barangay_information` VALUES (1,"475833425615585ba3837f","Barangay 557","Zone 57","District IV","1038 Roxas St, Sampaloc Manila","618278480618537394fd9a.png","../assets/dist/img/618278480618537394fd9a.png");


DROP TABLE IF EXISTS `blotter_complainant`;

CREATE TABLE `blotter_complainant` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `blotter_main` varchar(255) NOT NULL,
  `complainant_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `blotter_complainant` VALUES (1,1005546965199574,4011544830076411,000004),
(2,1094864133524925,10790186451242099,000010),
(3,186866067024556,5370116311040007,000004),
(4,365716613005842,2346524487292075,"");


DROP TABLE IF EXISTS `blotter_info`;

CREATE TABLE `blotter_info` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `blotter_main_id` varchar(255) NOT NULL,
  `blotter_person_id` varchar(255) NOT NULL,
  `blotter_complainant_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `blotter_record`;

CREATE TABLE `blotter_record` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `blotter_id` varchar(255) NOT NULL,
  `complainant_not_residence` varchar(255) NOT NULL,
  `statement` varchar(255) NOT NULL,
  `respodent` varchar(255) NOT NULL,
  `involved_not_resident` varchar(255) NOT NULL,
  `statement_person` varchar(255) NOT NULL,
  `date_incident` varchar(255) NOT NULL,
  `date_reported` varchar(255) NOT NULL,
  `type_of_incident` varchar(255) NOT NULL,
  `location_incident` varchar(255) NOT NULL,
  `status` varchar(69) NOT NULL,
  `remarks` varchar(69) NOT NULL,
  `date_added` varchar(255) NOT NULL,
  PRIMARY KEY (`blotter_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `blotter_status`;

CREATE TABLE `blotter_status` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `blotter_id` varchar(255) NOT NULL,
  `blotter_main` varchar(255) NOT NULL,
  `person_id` varchar(255) NOT NULL,
  PRIMARY KEY (`blotter_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `blotter_status` VALUES (1,503013787046687,4011544830076411,000001),
(2,901911362074670,10790186451242099,000005);


DROP TABLE IF EXISTS `carousel`;

CREATE TABLE `carousel` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `banner_title` varchar(255) NOT NULL,
  `banner_image` varchar(255) NOT NULL,
  `banner_image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `carousel` VALUES (1,1,"Sample 1","photo1.png","assets/dist/img/photo1.png"),
(2,2,"Sample 2","photo2.png","assets/dist/img/photo2.png");


DROP TABLE IF EXISTS `official_end_information`;

CREATE TABLE `official_end_information` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `official_id` varchar(255) NOT NULL,
  `first_name` varchar(69) NOT NULL,
  `middle_name` varchar(69) NOT NULL,
  `last_name` varchar(69) NOT NULL,
  `suffix` varchar(69) NOT NULL,
  `birth_date` varchar(69) NOT NULL,
  `birth_place` varchar(69) NOT NULL,
  `gender` varchar(69) NOT NULL,
  `age` varchar(69) NOT NULL,
  `civil_status` varchar(69) NOT NULL,
  `religion` varchar(69) NOT NULL,
  `nationality` varchar(69) NOT NULL,
  `municipality` varchar(69) NOT NULL,
  `zip` varchar(69) NOT NULL,
  `barangay` varchar(69) NOT NULL,
  `house_number` varchar(69) NOT NULL,
  `street` varchar(69) NOT NULL,
  `address` varchar(69) NOT NULL,
  `email_address` varchar(69) NOT NULL,
  `contact_number` varchar(69) NOT NULL,
  `fathers_name` varchar(69) NOT NULL,
  `mothers_name` varchar(69) NOT NULL,
  `guardian` varchar(69) NOT NULL,
  `guardian_contact` varchar(69) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`official_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `official_end_information` VALUES (1,"4058659036174f50c2419670ca14c2c36c76aef55d9fb4dd22162fe2","wqeqw","asdsadqqqqqqqqqqq","asdasqqqqqqqqqqqq","asdasdqqqqqqqqqqqqqqqq","1957-11-02","asdadqq","Female",63,"Married","asdasdqqqqqqqqqqqqqqqq","asdasdqqqqqqqqqqqqqqq","asdasdqqqqqq",23231111111111,"asdsad1qqqqq","wqwq3qqqqqqqqqqqqq","q3wq3wqqqqqqqqqqq","q3wq3qqqqqqqqqqqqq","wq3wq32@gmail.comqqqqqqqqqqqqqq",2321211,"qqqqqqqqqq","qqqqqqqqqqq","qqqqqqqqqqqqqqqq",1111111111111111111,"9377481006176c2bfb8e4b.jpg","../assets/dist/img/9377481006176c2bfb8e4b.jpg");


DROP TABLE IF EXISTS `official_end_status`;

CREATE TABLE `official_end_status` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `official_id` varchar(255) NOT NULL,
  `position` varchar(69) NOT NULL,
  `senior` varchar(69) NOT NULL,
  `term_from` varchar(69) NOT NULL,
  `term_to` varchar(69) NOT NULL,
  `pwd` varchar(69) NOT NULL,
  `status` varchar(69) NOT NULL,
  `voters` varchar(69) NOT NULL,
  `date_deleted` varchar(69) NOT NULL,
  PRIMARY KEY (`official_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `official_end_status` VALUES (1,"4058659036174f50c2419670ca14c2c36c76aef55d9fb4dd22162fe2","skkagawad","YES","2021-02-07","2024-07-02","NO","INACTIVE","NO","10/25/2021 03:43 PM");


DROP TABLE IF EXISTS `official_information`;

CREATE TABLE `official_information` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `official_id` varchar(255) NOT NULL,
  `first_name` varchar(69) NOT NULL,
  `middle_name` varchar(69) NOT NULL,
  `last_name` varchar(69) NOT NULL,
  `suffix` varchar(69) NOT NULL,
  `birth_date` varchar(69) NOT NULL,
  `birth_place` varchar(69) NOT NULL,
  `gender` varchar(69) NOT NULL,
  `age` varchar(69) NOT NULL,
  `civil_status` varchar(69) NOT NULL,
  `religion` varchar(69) NOT NULL,
  `nationality` varchar(69) NOT NULL,
  `municipality` varchar(69) NOT NULL,
  `zip` varchar(69) NOT NULL,
  `barangay` varchar(69) NOT NULL,
  `house_number` varchar(69) NOT NULL,
  `street` varchar(69) NOT NULL,
  `address` varchar(69) NOT NULL,
  `email_address` varchar(69) NOT NULL,
  `contact_number` varchar(69) NOT NULL,
  `fathers_name` varchar(69) NOT NULL,
  `mothers_name` varchar(69) NOT NULL,
  `guardian` varchar(69) NOT NULL,
  `guardian_contact` varchar(69) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`official_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `official_information` VALUES (1,"12714884296174f4049dfab692bc5528d7225b7c8b9b59cec1bf5fd2","first","middle","last","suffix","2015-03-03","place","Female",6,"Married","religion","nationality","municipality",132,"barangay","gouse","street","address","email@gmail.com",23123,"father","mother","guardian",23213,"",""),
(2,"4463656956173e9ae8af9f82e59b9182093058723e6eb56cbb697a6","Tolotot","","Kanor","jr","1997-09-06","Caloocan","Male",24,"Single","Catholic","Filipino","Caloocan City",1410,"Barangay","BLK 14 LOT 7","Street","Address","bugineeugine06@gmail.com","","rolando","lorna","lorna rosillon",12323211,"9080068796184098f368a8.png","../assets/dist/img/9080068796184098f368a8.png");


DROP TABLE IF EXISTS `official_status`;

CREATE TABLE `official_status` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `official_id` varchar(255) NOT NULL,
  `position` varchar(69) NOT NULL,
  `senior` varchar(69) NOT NULL,
  `term_from` varchar(69) NOT NULL,
  `term_to` varchar(69) NOT NULL,
  `pwd` varchar(69) NOT NULL,
  `status` varchar(69) NOT NULL,
  `voters` varchar(69) NOT NULL,
  `date_added` varchar(69) NOT NULL,
  PRIMARY KEY (`official_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `official_status` VALUES (1,"12714884296174f4049dfab692bc5528d7225b7c8b9b59cec1bf5fd2","skchairman","NO","2021-10-13","2021-10-28","YES","ACTIVE","YES","10/24/2021 01:49 PM"),
(2,"4463656956173e9ae8af9f82e59b9182093058723e6eb56cbb697a6","chairman","NO","2015-01-01","2020-01-01","YES","ACTIVE","YES","10/23/2021 06:53 PM");


DROP TABLE IF EXISTS `position`;

CREATE TABLE `position` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `position_id` varchar(255) NOT NULL,
  `position` varchar(69) NOT NULL,
  `position_description` varchar(255) NOT NULL,
  `status` varchar(69) NOT NULL,
  PRIMARY KEY (`position_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `residence_information`;

CREATE TABLE `residence_information` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `residence_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `age` varchar(11) NOT NULL,
  `suffix` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `civil_status` varchar(36) NOT NULL,
  `religion` varchar(36) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `contact_number` varchar(69) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `birth_date` varchar(255) NOT NULL,
  `birth_place` varchar(255) NOT NULL,
  `municipality` varchar(69) NOT NULL,
  `zip` int(69) NOT NULL,
  `barangay` varchar(69) NOT NULL,
  `house_number` varchar(69) NOT NULL,
  `street` varchar(69) NOT NULL,
  `fathers_name` varchar(255) NOT NULL,
  `mothers_name` varchar(255) NOT NULL,
  `guardian` varchar(69) NOT NULL,
  `guardian_contact` varchar(69) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`residence_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `residence_information` VALUES (1,000001,"John","","Doe",23,"","Female","Single","","","","","address","1997-09-06"," Caloccan","",0,"","","","","","","","1401255035617fe04741084.png","../assets/dist/img/1401255035617fe04741084.png"),
(2,000002,"first","middle","last",24,"suffix","Female","Single","religion","nationality",312312,"qweqw@gmail.cpm","address","1997-09-06","   caloocan","municipality",13,"barangay",12,"we","qwe","qwe","wqe","","",""),
(3,000003,"Riches","walwal","Sano",86,"","Female","Married","","","","","asdasdasd","1934-11-16","asdasd","",0,"","","","","","","","",""),
(4,000004,"asd","asd","asd",81,"","Male","Single","","","","","asdasd","1940-06-12","dasdasd","",0,"","","","","","","","",""),
(5,000005,"asd","asdsa","dasd",14,"","Male","Single","","","","","asdasd","2007-10-17","adasdasd","",0,"","","","","","","","",""),
(6,000006,"dfdcxv","cxv","xcvcxv",11,"","Male","Single","","","","","cxvxcvcxv","2010-10-05","asdasd","",0,"","","","","","","","",""),
(7,000007,"cxv","cxvcx","vcxv",13,"","Male","Single","","","","","xcvcxv","2008-10-05","cxvcxv","",0,"","","","","","","","",""),
(8,000008,"cxvcxv","cxv","vcxv",13,"cxv","Female","Single","cxvcxvc","","","","cvcxvcxv","2008-10-22","cxv","",0,"","","","","","","","",""),
(9,000009,"cxvasdasdasdasdasdasdwqewqewq","cxvasdsadasdsadwqewq","cxvasdasdasdasdaswqewqe",30,"cxv","Female","Single","xcv","cxv","","","cxvcxv","1991-06-05","  cxv","cxv",0,"cxv","","","","","","","",""),
(10,000010,"das","dasd","asd","","asdasd","Male","Single","","","","","asdasd","2021-11-05","asdas","",0,"","","","","","","","",""),
(11,000011,"hjg","hgjgh","jghj",3,"hgj","Female","Single","ghj","","","","ghjhj","2018-05-05","cxvcxvcxv","",0,"","","","","","","","",""),
(12,000012,"hgj","ghj","ghjghj",16,"ghj","Female","Single","ghj","ghj","","","ghjghj","2005-06-05","hgjhgj","",0,"","","","","","","","",""),
(13,00001311052021230331274,"wqe","wqe","qwe","","","Female","Single","","","","","qwewqe","2021-11-30","qwe","",0,"","","","","","","","",""),
(14,131105202123033127511052021230413478,"qwe","wqewqe","wqewqe","","","Male","Single","wqe","wqe","","","wqewqe","2021-11-02","qwe","qwe",0,"","","","","","","","","");


DROP TABLE IF EXISTS `residence_status`;

CREATE TABLE `residence_status` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `residence_id` varchar(255) NOT NULL,
  `status` varchar(69) NOT NULL,
  `voters` varchar(69) NOT NULL,
  `pwd` varchar(69) NOT NULL,
  `senior` varchar(69) NOT NULL,
  `archive` varchar(69) NOT NULL,
  `date_added` varchar(69) NOT NULL,
  `date_archive` varchar(69) NOT NULL,
  `date_unarchive` varchar(69) NOT NULL,
  PRIMARY KEY (`residence_id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `residence_status` VALUES (1,000001,"ACTIVE","YES","NO","NO","NO","11/01/2021 08:40 PM","",""),
(2,000002,"INACTIVE","YES","YES","NO","NO","11/01/2021 08:46 PM","",""),
(3,000003,"ACTIVE","YES","YES","YES","NO","11/05/2021 08:20 PM","",""),
(4,000004,"INACTIVE","NO","YES","YES","NO","11/05/2021 08:20 PM","",""),
(5,000005,"ACTIVE","NO","YES","NO","NO","11/05/2021 08:21 PM","",""),
(6,000006,"ACTIVE","YES","YES","NO","NO","11/05/2021 08:22 PM","",""),
(7,000007,"ACTIVE","YES","YES","NO","NO","11/05/2021 08:22 PM","",""),
(8,000008,"ACTIVE","YES","YES","NO","NO","11/05/2021 08:22 PM","",""),
(9,000009,"ACTIVE","NO","YES","NO","NO","11/05/2021 08:23 PM","",""),
(10,000010,"ACTIVE","NO","NO","NO","NO","11/05/2021 08:23 PM","",""),
(11,000011,"ACTIVE","YES","NO","NO","NO","11/05/2021 08:23 PM","",""),
(12,000012,"ACTIVE","YES","YES","NO","NO","11/05/2021 08:23 PM","",""),
(13,00001311052021230331274,"ACTIVE","YES","YES","NO","NO","11/05/2021 11:03 PM","",""),
(14,131105202123033127511052021230413478,"ACTIVE","YES","YES","NO","NO","11/05/2021 11:04 PM","","");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `foreign_key` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `foreign_key` (`foreign_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` VALUES (1,000001,"","","",000001,11012021204039178,"resident","",""),
(2,000002,"","","","username","password","resident","",""),
(3,000003,"","","",000003,11052021202024987,"resident","",""),
(4,000004,"","","",000004,11052021202050371,"resident","",""),
(5,000005,"","","",000005,11052021202152425,"resident","",""),
(6,000006,"","","",000006,11052021202209780,"resident","",""),
(7,000007,"","","",000007,11052021202227539,"resident","",""),
(8,000008,"","","",000008,11052021202247824,"resident","",""),
(9,000009,"","","",000009,11052021202308035,"resident","",""),
(10,000010,"","","",000010,11052021202318474,"resident","",""),
(11,000011,"","","",000011,11052021202331815,"resident","",""),
(12,000012,"","","",000012,11052021202346798,"resident","",""),
(13,00001311052021230331274,"","","",00001311052021230331274,11052021230331273,"resident","",""),
(14,1,"admin","admin","admin","admin","admin","admin","",""),
(15,131105202123033127511052021230413478,"","","",131105202123033127511052021230413478,11052021230413478,"resident","","");


SET foreign_key_checks = 1;
